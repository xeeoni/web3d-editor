import React, { useState, useEffect } from 'react'
import { useEditorStore } from '../store/editorStore'
import { getThreeObject } from '../hooks/useScene'
import * as THREE from 'three'

export default function Statusbar({ coord }: { coord: { x: number; y: number } }) {
  const { statusMessage, objects } = useEditorStore()
  const [fps, setFps] = useState(0)

  useEffect(() => {
    let frames = 0
    let last = Date.now()
    let id: number
    const count = () => {
      frames++
      const now = Date.now()
      if (now - last > 500) {
        setFps(Math.round(frames * 1000 / (now - last)))
        frames = 0; last = now
      }
      id = requestAnimationFrame(count)
    }
    id = requestAnimationFrame(count)
    return () => cancelAnimationFrame(id)
  }, [])

  let verts = 0, faces = 0
  objects.forEach(obj => {
    const threeObj = getThreeObject(obj.id)
    if (!threeObj) return
    const mesh = threeObj as THREE.Mesh
    if (!mesh.geometry) return
    const pos = mesh.geometry.attributes.position
    if (pos) verts += pos.count
    const idx = mesh.geometry.index
    faces += idx ? idx.count / 3 : pos ? pos.count / 3 : 0
  })

  return (
    <div className="flex items-center gap-4 px-3 bg-[#1e1e1e] border-t border-[#111] text-[10px] text-[#888] font-mono select-none">
      <span className="flex-1 truncate">{statusMessage}</span>
      <span className="ml-auto">X: {coord.x.toFixed(2)}  Y: {coord.y.toFixed(2)}</span>
      <span>Verts: {Math.round(verts)}</span>
      <span>Faces: {Math.round(faces)}</span>
      <span>{fps} fps</span>
    </div>
  )
}
