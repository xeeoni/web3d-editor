import React, { useRef, useEffect, useCallback } from 'react'
import { useEditorStore } from '../store/editorStore'
import { getThreeObject } from '../hooks/useScene'

export default function Timeline() {
  const {
    objects, selectedId, keyframes, currentFrame, endFrame,
    isPlaying, autoKey, setPlaying, setCurrentFrame,
    insertKeyframe, toggleAutoKey, setStatus,
  } = useEditorStore()

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animRef = useRef<number>(0)

  const drawTimeline = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    const w = canvas.width, h = canvas.height
    ctx.fillStyle = '#1a1a1a'
    ctx.fillRect(0, 0, w, h)

    const fw = w / endFrame
    for (let f = 1; f <= endFrame; f += 10) {
      ctx.fillStyle = '#2a2a2a'
      ctx.fillRect(f * fw, 0, 1, h)
      ctx.fillStyle = '#555'
      ctx.font = '9px monospace'
      ctx.fillText(String(f), f * fw + 2, 12)
    }

    Object.entries(keyframes).forEach(([id, kfs]) => {
      const isSelected = id === selectedId
      kfs.forEach(kf => {
        ctx.beginPath()
        ctx.arc(kf.frame * fw, 50, isSelected ? 6 : 4, 0, Math.PI * 2)
        ctx.fillStyle = isSelected ? '#e08030' : '#6688aa'
        ctx.fill()
      })
    })

    ctx.fillStyle = '#e05050'
    ctx.fillRect(currentFrame * fw - 1, 0, 2, h)
  }, [keyframes, currentFrame, endFrame, selectedId])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    canvas.width = canvas.parentElement?.clientWidth ?? 800
    canvas.height = 80
    drawTimeline()
  }, [drawTimeline])

  useEffect(() => {
    if (!isPlaying) return
    const tick = () => {
      setCurrentFrame(prev => {
        const next = prev >= endFrame ? 1 : prev + 1
        applyKeyframeInterp(next)
        return next
      })
    }
    const id = setInterval(tick, 1000 / 24)
    return () => clearInterval(id)
  }, [isPlaying, endFrame])

  function applyKeyframeInterp(frame: number) {
    objects.forEach(obj => {
      const kfs = keyframes[obj.id]
      if (!kfs || kfs.length < 2) return
      const threeObj = getThreeObject(obj.id)
      if (!threeObj) return
      let prev = kfs[0], next = kfs[kfs.length - 1]
      for (let i = 0; i < kfs.length - 1; i++) {
        if (kfs[i].frame <= frame && kfs[i+1].frame >= frame) {
          prev = kfs[i]; next = kfs[i+1]; break
        }
      }
      if (prev === next) return
      const t = (frame - prev.frame) / (next.frame - prev.frame)
      threeObj.position.lerpVectors(
        new (require('three')).Vector3(prev.position.x, prev.position.y, prev.position.z),
        new (require('three')).Vector3(next.position.x, next.position.y, next.position.z),
        t
      )
    })
  }

  function handleInsertKeyframe() {
    if (!selectedId) { setStatus('Select an object first'); return }
    const threeObj = getThreeObject(selectedId)
    if (!threeObj) return
    insertKeyframe(selectedId, currentFrame, {
      position: { x: threeObj.position.x, y: threeObj.position.y, z: threeObj.position.z },
      rotation: { x: threeObj.rotation.x, y: threeObj.rotation.y, z: threeObj.rotation.z },
      scale: { x: threeObj.scale.x, y: threeObj.scale.y, z: threeObj.scale.z },
    })
    setStatus(`Keyframe inserted at frame ${currentFrame}`)
  }

  function handleCanvasClick(e: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!
    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const frame = Math.round((x / canvas.width) * endFrame)
    setCurrentFrame(Math.max(1, Math.min(endFrame, frame)))
  }

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-[#1e1e1e] border-t border-[#111] font-mono text-[11px] z-20">
      <div className="flex items-center gap-2 px-2 py-1 bg-[#1e1e1e] border-b border-[#111]">
        <span className="text-[10px] text-[#aaa] uppercase tracking-widest mr-2">Timeline</span>
        <TlBtn onClick={() => setCurrentFrame(Math.max(1, currentFrame - 1))}>⏮</TlBtn>
        <TlBtn onClick={() => setPlaying(!isPlaying)}>{isPlaying ? '⏸ Pause' : '▶ Play'}</TlBtn>
        <TlBtn onClick={() => setCurrentFrame(Math.min(endFrame, currentFrame + 1))}>⏭</TlBtn>
        <span className="text-[#888] text-[10px] ml-2">
          Frame: <span className="text-[#ccc]">{currentFrame}</span> / {endFrame}
        </span>
        <TlBtn onClick={toggleAutoKey} active={autoKey}>○ AutoKey</TlBtn>
        <TlBtn onClick={handleInsertKeyframe}>◆ Key (I)</TlBtn>
      </div>
      <canvas ref={canvasRef} onClick={handleCanvasClick} className="w-full cursor-crosshair" style={{ height: 80 }} />
    </div>
  )
}

function TlBtn({ onClick, children, active }: { onClick: () => void; children: React.ReactNode; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`px-2 py-[2px] text-[10px] border rounded cursor-pointer font-mono ${active ? 'bg-[#e08030] border-[#e08030] text-white' : 'bg-[#333] border-[#444] text-[#ccc] hover:bg-[#444]'}`}
    >
      {children}
    </button>
  )
}
