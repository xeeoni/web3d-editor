import React, { useRef, useEffect, useCallback } from 'react'
import * as THREE from 'three'
import { getCamera } from '../hooks/useScene'
import { getSpherical, updateCameraPosition } from '../hooks/useOrbitControls'

export default function Gizmo({ onCameraChange }: { onCameraChange?: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    const camera = getCamera()
    if (!canvas || !camera) return
    const ctx = canvas.getContext('2d')!
    ctx.clearRect(0, 0, 80, 80)
    const cx = 40, cy = 40

    const axes = [
      { label: 'X', color: '#e05050', dir: new THREE.Vector3(1, 0, 0) },
      { label: 'Y', color: '#50c050', dir: new THREE.Vector3(0, 1, 0) },
      { label: 'Z', color: '#5080e0', dir: new THREE.Vector3(0, 0, 1) },
    ]

    const camPos = camera.position.clone().normalize()
    const right = new THREE.Vector3().crossVectors(camera.up, camPos).normalize()
    const up = new THREE.Vector3().crossVectors(camPos, right).normalize()

    axes.forEach(({ label, color, dir }) => {
      const x2d = dir.dot(right) * 28 + cx
      const y2d = -dir.dot(up) * 28 + cy
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x2d, y2d)
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke()
      ctx.beginPath(); ctx.arc(x2d, y2d, 5, 0, Math.PI * 2)
      ctx.fillStyle = color; ctx.fill()
      ctx.fillStyle = '#fff'; ctx.font = 'bold 8px monospace'
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
      ctx.fillText(label, x2d, y2d)
    })

    ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2)
    ctx.fillStyle = '#ccc'; ctx.fill()
  }, [])

  useEffect(() => {
    draw()
  })

  function handleClick(e: React.MouseEvent) {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect()
    const cx = e.clientX - rect.left - 40
    const cy = e.clientY - rect.top - 40
    const sp = getSpherical()
    if (Math.abs(cx) > Math.abs(cy)) {
      sp.phi = Math.PI / 2
      sp.theta = cx > 0 ? Math.PI / 2 : -Math.PI / 2
    } else {
      if (cy < 0) { sp.phi = 0.05; sp.theta = 0 }
      else { sp.phi = Math.PI / 2; sp.theta = 0 }
    }
    updateCameraPosition()
    onCameraChange?.()
  }

  return (
    <canvas
      ref={canvasRef}
      width={80} height={80}
      onClick={handleClick}
      className="absolute bottom-10 right-2 w-20 h-20 rounded-full border border-white/10 bg-black/40 cursor-pointer z-10"
      title="Click axes to snap view"
    />
  )
}
