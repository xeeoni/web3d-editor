import React, { useRef, useCallback, useState, useEffect } from 'react'
import * as THREE from 'three'
import { useEditorStore, ObjectType } from '../store/editorStore'
import { useSceneSetup, getCamera, getScene, getThreeObject, spawnObject } from '../hooks/useScene'
import { useOrbitControls } from '../hooks/useOrbitControls'
import Gizmo from './Gizmo'
import Timeline from './Timeline'

const VIEWS = ['top','front','right','camera'] as const
const PROJECTIONS = ['perspective','orthographic'] as const

export default function Viewport() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [coord, setCoord] = useState({ x: 0, y: 0 })
  const [hintMsg, setHintMsg] = useState('')
  const hintTimer = useRef<ReturnType<typeof setTimeout>>()
  const [forceUpdate, setForceUpdate] = useState(0)

  const {
    selectedId, selectObject, objects,
    editorMode, setEditorMode,
    viewportMode, setViewportMode,
    projection, setProjection,
    showGrid, toggleGrid,
    showAxes, toggleAxes,
    showTimeline,
    setTransformTool, transformTool,
    addObject, setStatus,
    removeObject,
  } = useEditorStore()

  const { syncGrid, syncAxes } = useSceneSetup(canvasRef, containerRef)

  useEffect(() => { syncGrid(showGrid) }, [showGrid, syncGrid])
  useEffect(() => { syncAxes(showAxes) }, [showAxes, syncAxes])

  useEffect(() => {
    const scene = getScene()
    if (!scene) return
    objects.forEach(obj => {
      const threeObj = getThreeObject(obj.id)
      if (!threeObj) return
      threeObj.visible = obj.visible
      const mesh = threeObj as THREE.Mesh
      if (!mesh.material) return
      const mat = mesh.material as THREE.MeshStandardMaterial
      if (viewportMode === 'wireframe') mat.wireframe = true
      else mat.wireframe = false
    })
  }, [viewportMode, objects])

  function showHint(msg: string) {
    setHintMsg(msg)
    clearTimeout(hintTimer.current)
    hintTimer.current = setTimeout(() => setHintMsg(''), 1600)
  }

  const handlePick = useCallback((mx: number, my: number) => {
    const scene = getScene()
    const camera = getCamera()
    if (!scene || !camera) return
    const raycaster = new THREE.Raycaster()
    raycaster.setFromCamera(new THREE.Vector2(mx, my), camera)
    const meshes: THREE.Object3D[] = []
    scene.traverse(child => { if (child.userData.id) meshes.push(child) })
    const hits = raycaster.intersectObjects(meshes, true)
    if (hits.length > 0) {
      const hit = hits[0].object
      const id = hit.userData.id || hit.parent?.userData.id
      if (id) { selectObject(id); setStatus(`Selected: ${objects.find(o => o.id === id)?.name ?? id}`); return }
    }
    selectObject(null)
  }, [objects, selectObject, setStatus])

  const handleCoord = useCallback((cx: number, cy: number) => {
    setCoord({ x: cx, y: cy })
  }, [])

  const handleCameraChange = useCallback(() => {
    setForceUpdate(n => n + 1)
  }, [])

  useOrbitControls(canvasRef, handleCameraChange, handlePick, handleCoord)

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.target instanceof HTMLInputElement) return
      switch (e.key) {
        case 'g': case 'G': setTransformTool('move'); showHint('G — Grab / Move'); break
        case 'r': case 'R': setTransformTool('rotate'); showHint('R — Rotate'); break
        case 's': case 'S': setTransformTool('scale'); showHint('S — Scale'); break
        case 'Delete': case 'Backspace':
          if (selectedId) {
            const { removeThreeObject } = require('../hooks/useScene')
            removeThreeObject(selectedId)
            removeObject(selectedId)
            setStatus('Object deleted')
          }
          break
        case 'D':
        case 'd':
          if (e.shiftKey && selectedId) {
            const src = objects.find(o => o.id === selectedId)
            if (src) {
              const obj = spawnObject(src.type)
              if (obj) { addObject(obj); selectObject(obj.id); setStatus(`Duplicated as ${obj.name}`) }
            }
          }
          break
        case 'Tab': setEditorMode(editorMode === 'object' ? 'edit' : 'object'); break
        case 'A': case 'a': if (e.shiftKey) setStatus('Shift+A: Use the Add button in the topbar'); break
        case '1': setView('front'); break
        case '3': setView('right'); break
        case '7': setView('top'); break
        case '5': setProjection(projection === 'perspective' ? 'orthographic' : 'perspective'); break
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [selectedId, objects, editorMode, projection])

  function setView(view: 'top'|'front'|'right'|'camera') {
    const { getSpherical, updateCameraPosition } = require('../hooks/useOrbitControls')
    const sp = getSpherical()
    if (view === 'top') { sp.phi = 0.05; sp.theta = 0 }
    else if (view === 'front') { sp.phi = Math.PI/2; sp.theta = 0 }
    else if (view === 'right') { sp.phi = Math.PI/2; sp.theta = Math.PI/2 }
    else if (view === 'camera') { sp.phi = Math.PI/4; sp.theta = Math.PI/4 }
    updateCameraPosition()
    setForceUpdate(n => n + 1)
  }

  const selectedObj = objects.find(o => o.id === selectedId)

  return (
    <div ref={containerRef} className="relative w-full h-full bg-[#1a1a1a] overflow-hidden select-none">
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* Top-left overlay */}
      <div className="absolute top-2 left-2 flex flex-col gap-1 pointer-events-auto z-10">
        <div className="flex gap-1">
          {PROJECTIONS.map(p => (
            <VpBtn key={p} active={projection === p} onClick={() => setProjection(p)}>
              {p === 'perspective' ? 'Persp' : 'Ortho'}
            </VpBtn>
          ))}
        </div>
        <div className="flex gap-1 flex-wrap max-w-[130px]">
          {(['top','front','right','camera'] as const).map(v => (
            <VpBtn key={v} onClick={() => setView(v)}>{v.charAt(0).toUpperCase() + v.slice(1)}</VpBtn>
          ))}
        </div>
      </div>

      {/* Top-right overlay */}
      <div className="absolute top-2 right-2 flex gap-1 pointer-events-auto z-10">
        <VpBtn onClick={toggleGrid} active={showGrid}>Grid</VpBtn>
        <VpBtn onClick={toggleAxes} active={showAxes}>Axes</VpBtn>
      </div>

      {/* Bottom-left info */}
      <div className="absolute bottom-2 left-2 flex gap-2 items-center pointer-events-none z-10">
        <VpLabel>{editorMode === 'object' ? 'Object Mode' : 'Edit Mode'}</VpLabel>
        <VpLabel>{objects.length} obj</VpLabel>
        <VpLabel>{coord.x.toFixed(2)}, {coord.y.toFixed(2)}</VpLabel>
      </div>

      {/* Transform hint */}
      {hintMsg && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/80 border border-[#e08030] text-[#e08030] px-4 py-2 rounded text-[13px] font-mono pointer-events-none z-20">
          {hintMsg}
        </div>
      )}

      {/* Gizmo */}
      <Gizmo onCameraChange={handleCameraChange} />

      {/* Timeline */}
      {showTimeline && <Timeline />}
    </div>
  )
}

function VpBtn({ onClick, children, active }: { onClick: () => void; children: React.ReactNode; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`px-2 py-[2px] text-[10px] rounded border font-mono cursor-pointer backdrop-blur-sm
        ${active
          ? 'bg-[rgba(224,128,48,0.7)] border-[#e08030] text-white'
          : 'bg-[rgba(0,0,0,0.55)] border-white/10 text-[#bbb] hover:bg-[rgba(60,60,60,0.8)] hover:text-white'}`}
    >
      {children}
    </button>
  )
}

function VpLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="bg-black/50 border border-white/10 text-[#aaa] px-2 py-[1px] text-[10px] rounded font-mono">
      {children}
    </span>
  )
}
