import React, { useState, useRef } from 'react'
import { useEditorStore, ObjectType } from '../store/editorStore'
import { spawnObject } from '../hooks/useScene'
import { getCamera, getScene, getRenderer } from '../hooks/useScene'

const MESH_TYPES: { label: string; type: ObjectType; icon: string }[] = [
  { label: 'Cube', type: 'cube', icon: '■' },
  { label: 'Sphere', type: 'sphere', icon: '●' },
  { label: 'Plane', type: 'plane', icon: '▬' },
  { label: 'Cylinder', type: 'cylinder', icon: '⬡' },
  { label: 'Cone', type: 'cone', icon: '▲' },
  { label: 'Torus', type: 'torus', icon: '◎' },
]
const LIGHT_TYPES: { label: string; type: ObjectType; icon: string }[] = [
  { label: 'Point Light', type: 'point-light', icon: '✦' },
  { label: 'Spot Light', type: 'spot-light', icon: '⊙' },
  { label: 'Directional', type: 'dir-light', icon: '☀' },
]
const OTHER_TYPES: { label: string; type: ObjectType; icon: string }[] = [
  { label: 'Camera', type: 'camera', icon: '📷' },
  { label: 'Empty', type: 'empty', icon: '✕' },
]

export default function Topbar() {
  const {
    editorMode, setEditorMode,
    viewportMode, setViewportMode,
    showTimeline, toggleTimeline,
    addObject, setStatus,
  } = useEditorStore()

  const [addMenuOpen, setAddMenuOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  function handleAdd(type: ObjectType) {
    setAddMenuOpen(false)
    const obj = spawnObject(type)
    if (obj) {
      addObject(obj)
      useEditorStore.getState().selectObject(obj.id)
      setStatus(`Added ${obj.name}`)
    }
  }

  function handleRender() {
    const renderer = getRenderer()
    const camera = getCamera()
    const scene = getScene()
    if (!renderer || !camera || !scene) return
    renderer.render(scene, camera)
    const canvas = renderer.domElement
    const link = document.createElement('a')
    link.download = 'render.png'
    link.href = canvas.toDataURL('image/png')
    link.click()
    setStatus('Render saved as render.png')
  }

  return (
    <div className="flex items-center gap-1 px-2 bg-[#2a2a2a] border-b border-[#111] h-8 select-none z-50 relative text-[11px]">
      <span className="text-[#e08030] font-bold text-[13px] mr-2">▲ WEB3D</span>
      <div className="w-px h-5 bg-[#444] mx-1" />

      <div className="relative" ref={menuRef}>
        <button
          className="topbar-btn"
          onClick={() => setAddMenuOpen(!addMenuOpen)}
        >＋ Add</button>
        {addMenuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setAddMenuOpen(false)} />
            <div className="absolute left-0 top-full mt-1 bg-[#2a2a2a] border border-[#444] rounded shadow-2xl z-50 min-w-[160px]">
              <div className="px-3 py-1 text-[9px] text-[#666] uppercase tracking-widest">Mesh</div>
              {MESH_TYPES.map(t => (
                <button key={t.type} onClick={() => handleAdd(t.type)} className="add-item">
                  <span>{t.icon}</span> {t.label}
                </button>
              ))}
              <div className="h-px bg-[#333] my-1" />
              <div className="px-3 py-1 text-[9px] text-[#666] uppercase tracking-widest">Light</div>
              {LIGHT_TYPES.map(t => (
                <button key={t.type} onClick={() => handleAdd(t.type)} className="add-item">
                  <span>{t.icon}</span> {t.label}
                </button>
              ))}
              <div className="h-px bg-[#333] my-1" />
              <div className="px-3 py-1 text-[9px] text-[#666] uppercase tracking-widest">Other</div>
              {OTHER_TYPES.map(t => (
                <button key={t.type} onClick={() => handleAdd(t.type)} className="add-item">
                  <span>{t.icon}</span> {t.label}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="w-px h-5 bg-[#444] mx-1" />
      <button className={`topbar-btn ${editorMode === 'object' ? 'active' : ''}`} onClick={() => setEditorMode('object')}>Object</button>
      <button className={`topbar-btn ${editorMode === 'edit' ? 'active' : ''}`} onClick={() => setEditorMode('edit')}>Edit</button>

      <div className="w-px h-5 bg-[#444] mx-1" />
      <span className="text-[#888] mx-1">View:</span>
      {(['solid','wireframe','material'] as const).map(m => (
        <button key={m} className={`topbar-btn ${viewportMode === m ? 'active' : ''}`} onClick={() => setViewportMode(m)}>
          {m.charAt(0).toUpperCase() + m.slice(1, m === 'wireframe' ? 4 : undefined)}
        </button>
      ))}

      <div className="w-px h-5 bg-[#444] mx-1" />
      <button className={`topbar-btn ${showTimeline ? 'active' : ''}`} onClick={toggleTimeline}>Timeline</button>

      <div className="w-px h-5 bg-[#444] mx-1" />
      <button className="topbar-btn" onClick={handleRender}>⬛ Render</button>

      <div className="flex-1" />
      <span className="text-[#444] text-[10px]">WebGL · Three.js r158</span>

      <style>{`
        .topbar-btn { background:#333; border:1px solid #444; color:#ccc; padding:2px 8px; font-size:10px; border-radius:3px; cursor:pointer; white-space:nowrap; font-family:inherit; }
        .topbar-btn:hover { background:#444; border-color:#555; }
        .topbar-btn.active { background:#e08030; border-color:#e08030; color:#fff; }
        .add-item { display:flex; align-items:center; gap:8px; width:100%; padding:5px 12px; font-size:11px; color:#ccc; cursor:pointer; background:transparent; border:none; text-align:left; font-family:inherit; }
        .add-item:hover { background:rgba(224,128,48,0.2); color:#fff; }
      `}</style>
    </div>
  )
}
