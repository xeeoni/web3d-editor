import React, { useState } from 'react'
import { useEditorStore } from '../store/editorStore'
import { objectIcon, removeThreeObject, spawnObject } from '../hooks/useScene'

export default function Outliner() {
  const { objects, selectedId, selectObject, updateObject, removeObject, addObject, setStatus, duplicateObject } = useEditorStore()
  const [search, setSearch] = useState('')

  const filtered = search
    ? objects.filter(o => o.name.toLowerCase().includes(search.toLowerCase()))
    : objects

  function toggleVis(e: React.MouseEvent, id: string) {
    e.stopPropagation()
    const obj = objects.find(o => o.id === id)
    if (!obj) return
    updateObject(id, { visible: !obj.visible })
    const { getThreeObject, getThreeLight } = require('../hooks/useScene')
    // visibility synced in Viewport via store subscription
  }

  function handleDelete(id: string) {
    removeThreeObject(id)
    removeObject(id)
    setStatus('Object deleted')
  }

  function handleDuplicate() {
    if (!selectedId) return
    const clone = duplicateObject(selectedId)
    if (!clone) return
    const src = objects.find(o => o.id === selectedId)
    if (!src) return
    const newObj = spawnObject(src.type)
    if (!newObj) return
    newObj.name = clone.name
    addObject({ ...newObj, id: clone.id, name: clone.name })
    selectObject(newObj.id)
    setStatus(`Duplicated as ${newObj.name}`)
  }

  return (
    <div className="flex flex-col h-full bg-[#252525] text-[11px] text-[#ccc] font-mono overflow-hidden">
      <div className="flex items-center justify-between px-2 py-1 bg-[#1e1e1e] border-b border-[#111] flex-shrink-0">
        <span className="text-[10px] text-[#aaa] uppercase tracking-widest">Scene Outliner</span>
        <span className="text-[#e08030] text-[9px] cursor-pointer">⊞</span>
      </div>

      <div className="px-2 py-1 border-b border-[#111] flex-shrink-0">
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-[#1a1a1a] border border-[#333] text-[#e8e8e8] px-2 py-1 text-[10px] rounded focus:outline-none focus:border-[#e08030] font-mono"
        />
      </div>

      <div className="flex-1 overflow-y-auto">
        {filtered.map(obj => (
          <div
            key={obj.id}
            onClick={() => selectObject(obj.id)}
            className={`flex items-center gap-1 px-2 py-[3px] cursor-pointer transition-colors rounded-sm mx-1 my-[1px]
              ${selectedId === obj.id ? 'bg-[rgba(224,128,48,0.25)] border-l-2 border-[#e08030]' : 'hover:bg-[rgba(255,255,255,0.05)]'}`}
          >
            <span className="w-4 text-center flex-shrink-0">{objectIcon(obj.type)}</span>
            <span className="flex-1 truncate text-[11px]">{obj.name}</span>
            <button
              onClick={e => toggleVis(e, obj.id)}
              className="opacity-40 hover:opacity-100 px-1 text-[11px] bg-transparent border-none text-[#ccc] cursor-pointer"
            >
              {obj.visible ? '👁' : '—'}
            </button>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="p-4 text-center text-[#555]">No objects</div>
        )}
      </div>

      {/* Tools */}
      <div className="border-t border-[#111] flex-shrink-0">
        <div className="px-2 py-1 bg-[#1e1e1e] text-[10px] text-[#aaa] uppercase tracking-widest border-b border-[#111]">Tools</div>
        <div className="p-2 grid grid-cols-2 gap-1">
          {(['move','rotate','scale'] as const).map(tool => (
            <ToolBtn key={tool} tool={tool} />
          ))}
          <button onClick={handleDuplicate} className="tool-btn text-[10px]">⧉ Dup (Shift+D)</button>
          <button
            onClick={() => selectedId && handleDelete(selectedId)}
            className="tool-btn col-span-2 text-[10px] border-[#e05050] text-[#e08080]"
          >✕ Delete (Del)</button>
        </div>
      </div>

      <style>{`
        .tool-btn { background:#2a2a2a; border:1px solid #3a3a3a; color:#aaa; padding:3px 6px; font-size:10px; border-radius:3px; cursor:pointer; font-family:inherit; }
        .tool-btn:hover { background:#333; color:#ccc; }
        .tool-btn.active { background:#e08030; border-color:#e08030; color:#fff; }
      `}</style>
    </div>
  )
}

function ToolBtn({ tool }: { tool: 'move' | 'rotate' | 'scale' }) {
  const { transformTool, setTransformTool } = useEditorStore()
  const icons = { move: '↔', rotate: '↻', scale: '⊞' }
  const keys = { move: 'G', rotate: 'R', scale: 'S' }
  return (
    <button
      className={`tool-btn text-[10px] ${transformTool === tool ? 'active' : ''}`}
      onClick={() => setTransformTool(tool)}
    >
      {icons[tool]} {tool.charAt(0).toUpperCase() + tool.slice(1)} ({keys[tool]})
    </button>
  )
}
