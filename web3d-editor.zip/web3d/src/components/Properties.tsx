import React from 'react'
import { useEditorStore } from '../store/editorStore'
import { getThreeObject, getThreeLight } from '../hooks/useScene'
import * as THREE from 'three'

function XYZInput({
  label, values, onChange, step = 0.1, unit = ''
}: {
  label: string
  values: [number, number, number]
  onChange: (axis: 'x' | 'y' | 'z', val: number) => void
  step?: number
  unit?: string
}) {
  const colors = ['#e05050', '#50e050', '#5080e0']
  const axes = ['x', 'y', 'z'] as const
  return (
    <div className="flex items-center px-2 py-[3px] gap-1">
      <span className="text-[#888] text-[10px] w-14 flex-shrink-0">{label}</span>
      <div className="flex gap-[2px] flex-1">
        {axes.map((ax, i) => (
          <input
            key={ax}
            type="number"
            step={step}
            value={values[i].toFixed(3)}
            onChange={e => onChange(ax, parseFloat(e.target.value) || 0)}
            className="flex-1 min-w-0 bg-[#1a1a1a] border border-[#333] text-[#e8e8e8] py-[2px] px-1 text-[10px] rounded text-center font-mono focus:outline-none focus:border-[#e08030]"
            style={{ borderLeft: `2px solid ${colors[i]}` }}
          />
        ))}
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="px-2 mb-2">
      <div className="text-[10px] text-[#e08030] uppercase tracking-wider py-1 border-b border-[#333] mb-1">{title}</div>
      {children}
    </div>
  )
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center px-0 py-[3px] gap-2">
      <span className="text-[#888] text-[10px] w-14 flex-shrink-0">{label}</span>
      <div className="flex-1">{children}</div>
    </div>
  )
}

export default function Properties() {
  const { objects, selectedId, updateObject, setStatus } = useEditorStore()
  const obj = objects.find(o => o.id === selectedId)

  if (!obj) {
    return (
      <div className="flex flex-col h-full bg-[#252525] text-[11px] font-mono">
        <div className="px-2 py-1 bg-[#1e1e1e] border-b border-[#111]">
          <span className="text-[10px] text-[#aaa] uppercase tracking-widest">Properties</span>
        </div>
        <div className="flex-1 flex items-center justify-center text-[#555] text-[11px] p-4 text-center">
          Select an object to view properties
        </div>
      </div>
    )
  }

  const threeObj = getThreeObject(obj.id)
  const threeLight = getThreeLight(obj.id)

  const pos = threeObj ? threeObj.position : new THREE.Vector3()
  const rot = threeObj ? threeObj.rotation : new THREE.Euler()
  const scl = threeObj ? threeObj.scale : new THREE.Vector3(1,1,1)

  const toDeg = (v: number) => v * 180 / Math.PI
  const toRad = (v: number) => v * Math.PI / 180

  function updatePos(ax: 'x'|'y'|'z', val: number) {
    if (!threeObj) return
    threeObj.position[ax] = val
  }
  function updateRot(ax: 'x'|'y'|'z', val: number) {
    if (!threeObj) return
    threeObj.rotation[ax] = toRad(val)
  }
  function updateScale(ax: 'x'|'y'|'z', val: number) {
    if (!threeObj) return
    threeObj.scale[ax] = val
  }

  function updateColor(hex: string) {
    updateObject(obj.id, { color: hex })
    const mesh = threeObj as THREE.Mesh
    if (mesh?.material && (mesh.material as THREE.MeshStandardMaterial).color) {
      (mesh.material as THREE.MeshStandardMaterial).color.set(hex)
    }
  }

  function updateRoughness(val: number) {
    const mesh = threeObj as THREE.Mesh
    if (mesh?.material) (mesh.material as THREE.MeshStandardMaterial).roughness = val
  }

  function updateMetalness(val: number) {
    const mesh = threeObj as THREE.Mesh
    if (mesh?.material) (mesh.material as THREE.MeshStandardMaterial).metalness = val
  }

  function toggleWireframe(val: boolean) {
    const mesh = threeObj as THREE.Mesh
    if (mesh?.material) (mesh.material as THREE.MeshStandardMaterial).wireframe = val
  }

  function updateLightColor(hex: string) {
    if (threeLight) threeLight.color.set(hex)
  }

  function updateLightIntensity(val: number) {
    if (threeLight) threeLight.intensity = val
  }

  const mat = (threeObj as THREE.Mesh)?.material as THREE.MeshStandardMaterial | null

  return (
    <div className="flex flex-col h-full bg-[#252525] text-[11px] font-mono overflow-hidden">
      <div className="px-2 py-1 bg-[#1e1e1e] border-b border-[#111] flex-shrink-0 flex justify-between">
        <span className="text-[10px] text-[#aaa] uppercase tracking-widest">Properties</span>
        <span className="text-[#e08030] text-[9px]">⚙</span>
      </div>

      <div className="flex-1 overflow-y-auto py-2">
        <Section title="Object">
          <div className="flex items-center px-0 py-[3px] gap-2">
            <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Name</span>
            <input
              className="flex-1 bg-[#1a1a1a] border border-[#333] text-[#e8e8e8] px-2 py-[2px] text-[10px] rounded focus:outline-none focus:border-[#e08030] font-mono"
              value={obj.name}
              onChange={e => updateObject(obj.id, { name: e.target.value })}
            />
          </div>
          <div className="flex items-center px-0 py-[3px] gap-2">
            <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Type</span>
            <span className="text-[#aaa] text-[10px]">{obj.type}</span>
          </div>
        </Section>

        {threeObj && (
          <Section title="Transform">
            <XYZInput
              label="Location"
              values={[pos.x, pos.y, pos.z]}
              onChange={updatePos}
              step={0.1}
            />
            <XYZInput
              label="Rotation"
              values={[toDeg(rot.x), toDeg(rot.y), toDeg(rot.z)]}
              onChange={updateRot}
              step={1}
            />
            <XYZInput
              label="Scale"
              values={[scl.x, scl.y, scl.z]}
              onChange={updateScale}
              step={0.1}
            />
          </Section>
        )}

        {mat && (
          <Section title="Material">
            <div className="flex items-center px-0 py-[3px] gap-2">
              <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Color</span>
              <input
                type="color"
                value={obj.color || '#888888'}
                onChange={e => updateColor(e.target.value)}
                className="flex-1 h-6 rounded border border-[#333] cursor-pointer bg-transparent"
              />
            </div>
            <SliderRow label="Roughness" defaultValue={mat?.roughness ?? 0.7} onChange={updateRoughness} />
            <SliderRow label="Metallic" defaultValue={mat?.metalness ?? 0} onChange={updateMetalness} />
            <div className="flex items-center px-0 py-[3px] gap-2">
              <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Wireframe</span>
              <input type="checkbox" defaultChecked={mat?.wireframe ?? false} onChange={e => toggleWireframe(e.target.checked)} />
            </div>
          </Section>
        )}

        {threeLight && (
          <Section title="Light">
            <div className="flex items-center px-0 py-[3px] gap-2">
              <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Color</span>
              <input
                type="color"
                defaultValue="#ffffff"
                onChange={e => updateLightColor(e.target.value)}
                className="flex-1 h-6 rounded border border-[#333] cursor-pointer bg-transparent"
              />
            </div>
            <SliderRow label="Intensity" defaultValue={threeLight.intensity} min={0} max={5} onChange={updateLightIntensity} />
          </Section>
        )}

        <Section title="Visibility">
          <div className="flex items-center px-0 py-[3px] gap-2">
            <span className="text-[#888] text-[10px] w-14 flex-shrink-0">Visible</span>
            <input
              type="checkbox"
              checked={obj.visible}
              onChange={e => {
                updateObject(obj.id, { visible: e.target.checked })
                if (threeObj) threeObj.visible = e.target.checked
                if (threeLight) threeLight.visible = e.target.checked
              }}
            />
          </div>
        </Section>
      </div>
    </div>
  )
}

function SliderRow({ label, defaultValue, min = 0, max = 1, onChange }: {
  label: string; defaultValue: number; min?: number; max?: number; onChange: (v: number) => void
}) {
  const [val, setVal] = React.useState(defaultValue)
  return (
    <div className="flex items-center px-0 py-[3px] gap-2">
      <span className="text-[#888] text-[10px] w-14 flex-shrink-0">{label}</span>
      <input
        type="range" min={min} max={max} step={0.01} value={val}
        onChange={e => { const v = parseFloat(e.target.value); setVal(v); onChange(v) }}
        className="flex-1 accent-[#e08030]"
      />
      <span className="text-[#888] text-[10px] w-8 text-right">{(val * (max === 5 ? 1 : 100)).toFixed(max === 5 ? 1 : 0)}{max === 5 ? '' : '%'}</span>
    </div>
  )
}
