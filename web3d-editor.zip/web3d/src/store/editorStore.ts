import { create } from 'zustand'
import * as THREE from 'three'

export type ObjectType =
  | 'cube' | 'sphere' | 'plane' | 'cylinder' | 'cone' | 'torus'
  | 'point-light' | 'spot-light' | 'dir-light'
  | 'camera' | 'empty'

export type ViewportMode = 'solid' | 'wireframe' | 'material'
export type EditorMode = 'object' | 'edit'
export type ProjectionMode = 'perspective' | 'orthographic'
export type TransformTool = 'move' | 'rotate' | 'scale'

export interface SceneObject {
  id: string
  name: string
  type: ObjectType
  visible: boolean
  locked: boolean
  color: string
  mesh?: THREE.Object3D
  lightRef?: THREE.Light
  geometry?: THREE.BufferGeometry
  material?: THREE.MeshStandardMaterial
}

export interface Keyframe {
  frame: number
  position: { x: number; y: number; z: number }
  rotation: { x: number; y: number; z: number }
  scale: { x: number; y: number; z: number }
}

interface EditorState {
  objects: SceneObject[]
  selectedId: string | null
  editorMode: EditorMode
  viewportMode: ViewportMode
  projection: ProjectionMode
  transformTool: TransformTool
  showGrid: boolean
  showAxes: boolean
  showTimeline: boolean
  currentFrame: number
  endFrame: number
  isPlaying: boolean
  autoKey: boolean
  keyframes: Record<string, Keyframe[]>
  statusMessage: string

  addObject: (obj: SceneObject) => void
  removeObject: (id: string) => void
  selectObject: (id: string | null) => void
  updateObject: (id: string, patch: Partial<SceneObject>) => void
  setEditorMode: (mode: EditorMode) => void
  setViewportMode: (mode: ViewportMode) => void
  setProjection: (mode: ProjectionMode) => void
  setTransformTool: (tool: TransformTool) => void
  toggleGrid: () => void
  toggleAxes: () => void
  toggleTimeline: () => void
  setCurrentFrame: (frame: number) => void
  setPlaying: (playing: boolean) => void
  toggleAutoKey: () => void
  insertKeyframe: (objectId: string, frame: number, kf: Omit<Keyframe, 'frame'>) => void
  setStatus: (msg: string) => void
  duplicateObject: (id: string) => SceneObject | null
}

let objectCounter = 0

export function makeId() {
  return `obj_${++objectCounter}_${Date.now()}`
}

export const useEditorStore = create<EditorState>((set, get) => ({
  objects: [],
  selectedId: null,
  editorMode: 'object',
  viewportMode: 'solid',
  projection: 'perspective',
  transformTool: 'move',
  showGrid: true,
  showAxes: true,
  showTimeline: false,
  currentFrame: 1,
  endFrame: 120,
  isPlaying: false,
  autoKey: false,
  keyframes: {},
  statusMessage: 'Ready — Press Shift+A or click Add to create objects',

  addObject: (obj) => set((s) => ({ objects: [...s.objects, obj] })),
  removeObject: (id) =>
    set((s) => ({
      objects: s.objects.filter((o) => o.id !== id),
      selectedId: s.selectedId === id ? null : s.selectedId,
    })),
  selectObject: (id) => set({ selectedId: id }),
  updateObject: (id, patch) =>
    set((s) => ({
      objects: s.objects.map((o) => (o.id === id ? { ...o, ...patch } : o)),
    })),
  setEditorMode: (mode) => set({ editorMode: mode }),
  setViewportMode: (mode) => set({ viewportMode: mode }),
  setProjection: (mode) => set({ projection: mode }),
  setTransformTool: (tool) => set({ transformTool: tool }),
  toggleGrid: () => set((s) => ({ showGrid: !s.showGrid })),
  toggleAxes: () => set((s) => ({ showAxes: !s.showAxes })),
  toggleTimeline: () => set((s) => ({ showTimeline: !s.showTimeline })),
  setCurrentFrame: (frame) => set({ currentFrame: frame }),
  setPlaying: (playing) => set({ isPlaying: playing }),
  toggleAutoKey: () => set((s) => ({ autoKey: !s.autoKey })),
  insertKeyframe: (objectId, frame, kf) =>
    set((s) => {
      const existing = s.keyframes[objectId] ?? []
      const filtered = existing.filter((k) => k.frame !== frame)
      const updated = [...filtered, { frame, ...kf }].sort((a, b) => a.frame - b.frame)
      return { keyframes: { ...s.keyframes, [objectId]: updated } }
    }),
  setStatus: (msg) => set({ statusMessage: msg }),
  duplicateObject: (id) => {
    const s = get()
    const src = s.objects.find((o) => o.id === id)
    if (!src) return null
    const clone: SceneObject = {
      ...src,
      id: makeId(),
      name: src.name + '.copy',
      mesh: undefined,
      lightRef: undefined,
      geometry: undefined,
      material: undefined,
    }
    set((st) => ({ objects: [...st.objects, clone] }))
    return clone
  },
}))
