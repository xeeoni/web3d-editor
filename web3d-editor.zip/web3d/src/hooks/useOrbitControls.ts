import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { getCamera, getSpherical, updateCameraPosition as updateCam } from './useScene'

type OrbitState = { active: boolean; lastX: number; lastY: number; button: number }

export function useOrbitControls(
  canvasRef: React.RefObject<HTMLCanvasElement>,
  onCameraChange?: () => void,
  onPick?: (mx: number, my: number) => void,
  onCoordUpdate?: (cx: number, cy: number) => void,
) {
  const orbitState = useRef<OrbitState>({ active: false, lastX: 0, lastY: 0, button: -1 })
  const dragStart = useRef({ x: 0, y: 0 })
  const isDragging = useRef(false)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    function getPos(e: MouseEvent) {
      const r = canvas!.getBoundingClientRect()
      return { x: e.clientX - r.left, y: e.clientY - r.top }
    }

    function onDown(e: MouseEvent) {
      e.preventDefault()
      const pos = getPos(e)
      orbitState.current = { active: true, lastX: pos.x, lastY: pos.y, button: e.button }
      dragStart.current = { x: pos.x, y: pos.y }
      isDragging.current = false
    }

    function onMove(e: MouseEvent) {
      const pos = getPos(e)
      const rect = canvas!.getBoundingClientRect()
      const cx = (pos.x / rect.width) * 2 - 1
      const cy = -(pos.y / rect.height) * 2 + 1
      onCoordUpdate?.(cx, cy)

      if (!orbitState.current.active) return

      const dx = pos.x - orbitState.current.lastX
      const dy = pos.y - orbitState.current.lastY
      const moved = Math.abs(pos.x - dragStart.current.x) + Math.abs(pos.y - dragStart.current.y) > 3
      if (moved) isDragging.current = true

      const sp = getSpherical()
      const cam = getCamera()

      if (orbitState.current.button === 1 || (orbitState.current.button === 0 && e.altKey)) {
        sp.theta -= dx * 0.008
        sp.phi = Math.max(0.1, Math.min(Math.PI - 0.1, sp.phi + dy * 0.008))
        updateCam()
        onCameraChange?.()
      } else if (orbitState.current.button === 2) {
        if (!cam) return
        const panSpeed = sp.radius * 0.001
        const right = new THREE.Vector3().crossVectors(
          cam.getWorldDirection(new THREE.Vector3()), cam.up
        ).normalize()
        cam.position.addScaledVector(right, -dx * panSpeed)
        cam.position.y += dy * panSpeed
        cam.lookAt(0, 0, 0)
        onCameraChange?.()
      }

      orbitState.current.lastX = pos.x
      orbitState.current.lastY = pos.y
    }

    function onUp(e: MouseEvent) {
      if (!isDragging.current && orbitState.current.button === 0) {
        const pos = getPos(e)
        const rect = canvas!.getBoundingClientRect()
        const mx = (pos.x / rect.width) * 2 - 1
        const my = -(pos.y / rect.height) * 2 + 1
        onPick?.(mx, my)
      }
      orbitState.current.active = false
    }

    function onWheel(e: WheelEvent) {
      e.preventDefault()
      const sp = getSpherical()
      sp.radius = Math.max(0.5, Math.min(80, sp.radius + e.deltaY * 0.01))
      updateCam()
      onCameraChange?.()
    }

    canvas.addEventListener('mousedown', onDown)
    canvas.addEventListener('mousemove', onMove)
    canvas.addEventListener('mouseup', onUp)
    canvas.addEventListener('wheel', onWheel, { passive: false })
    canvas.addEventListener('contextmenu', (e) => e.preventDefault())

    return () => {
      canvas.removeEventListener('mousedown', onDown)
      canvas.removeEventListener('mousemove', onMove)
      canvas.removeEventListener('mouseup', onUp)
      canvas.removeEventListener('wheel', onWheel)
    }
  }, [canvasRef, onCameraChange, onPick, onCoordUpdate])
}

export function updateCameraPosition() {
  updateCam()
}
