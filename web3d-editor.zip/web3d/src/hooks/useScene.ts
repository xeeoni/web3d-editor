import { useEffect, useRef, useCallback } from 'react'
import * as THREE from 'three'
import { useEditorStore, ObjectType, SceneObject, makeId } from '../store/editorStore'

const OBJECT_ICONS: Record<string, string> = {
  cube: '■', sphere: '●', plane: '▬', cylinder: '⬡',
  cone: '▲', torus: '◎', camera: '📷',
  'point-light': '✦', 'spot-light': '⊙', 'dir-light': '☀', empty: '✕',
}

export function objectIcon(type: string) {
  return OBJECT_ICONS[type] ?? '○'
}

let sceneRef: THREE.Scene | null = null
let cameraRef: THREE.PerspectiveCamera | null = null
let orthoCameraRef: THREE.OrthographicCamera | null = null
let rendererRef: THREE.WebGLRenderer | null = null

const threeObjects = new Map<string, THREE.Object3D>()
const threeLights = new Map<string, THREE.Light>()

const spherical = { theta: -Math.PI / 5, phi: Math.PI / 3.5, radius: 9 }

function updateCameraPosition() {
  if (!cameraRef) return
  cameraRef.position.x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta)
  cameraRef.position.y = spherical.radius * Math.cos(spherical.phi)
  cameraRef.position.z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta)
  cameraRef.lookAt(0, 0, 0)
}

export function getScene() { return sceneRef }
export function getCamera() { return cameraRef }
export function getOrthoCamera() { return orthoCameraRef }
export function getRenderer() { return rendererRef }
export function getSpherical() { return spherical }
export function getThreeObject(id: string) { return threeObjects.get(id) }
export function getThreeLight(id: string) { return threeLights.get(id) }

function buildGeometry(type: ObjectType): THREE.BufferGeometry {
  switch (type) {
    case 'cube':     return new THREE.BoxGeometry(1, 1, 1)
    case 'sphere':   return new THREE.SphereGeometry(0.6, 32, 24)
    case 'plane':    return new THREE.PlaneGeometry(2, 2)
    case 'cylinder': return new THREE.CylinderGeometry(0.5, 0.5, 1.5, 32)
    case 'cone':     return new THREE.ConeGeometry(0.6, 1.5, 32)
    case 'torus':    return new THREE.TorusGeometry(0.6, 0.2, 16, 64)
    default:         return new THREE.BoxGeometry(1, 1, 1)
  }
}

export function spawnObject(type: ObjectType): SceneObject | null {
  const scene = sceneRef
  if (!scene) return null

  const id = makeId()
  const count = threeObjects.size + threeLights.size
  const name = type.charAt(0).toUpperCase() + type.slice(1) + '.' + String(count + 1).padStart(3, '0')

  const sceneObj: SceneObject = { id, name, type, visible: true, locked: false, color: '#888888' }

  if (['cube','sphere','plane','cylinder','cone','torus'].includes(type)) {
    const geo = buildGeometry(type)
    const mat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7, metalness: 0.1 })
    const mesh = new THREE.Mesh(geo, mat)
    mesh.castShadow = true
    mesh.receiveShadow = true
    if (type === 'plane') { mesh.rotation.x = -Math.PI / 2; mesh.position.y = -0.01 }
    else { mesh.position.set(Math.random() * 2 - 1, 0, Math.random() * 2 - 1) }
    mesh.userData.id = id
    scene.add(mesh)
    threeObjects.set(id, mesh)
    sceneObj.geometry = geo
    sceneObj.material = mat
  } else if (type === 'point-light') {
    const light = new THREE.PointLight(0xffffff, 1, 20)
    light.position.set(Math.random() * 4 - 2, 2, Math.random() * 4 - 2)
    light.castShadow = true
    scene.add(light)
    const helper = new THREE.PointLightHelper(light, 0.3)
    scene.add(helper)
    helper.userData.id = id
    threeObjects.set(id, helper)
    threeLights.set(id, light)
    sceneObj.color = '#ffdd88'
  } else if (type === 'spot-light') {
    const light = new THREE.SpotLight(0xffffff, 1)
    light.position.set(2, 4, 2); light.castShadow = true
    scene.add(light)
    const helper = new THREE.SpotLightHelper(light)
    scene.add(helper)
    helper.userData.id = id
    threeObjects.set(id, helper)
    threeLights.set(id, light)
    sceneObj.color = '#ffdd88'
  } else if (type === 'dir-light') {
    const light = new THREE.DirectionalLight(0xffffff, 1)
    light.position.set(5, 8, 3); light.castShadow = true
    scene.add(light)
    const helper = new THREE.DirectionalLightHelper(light, 1)
    scene.add(helper)
    helper.userData.id = id
    threeObjects.set(id, helper)
    threeLights.set(id, light)
    sceneObj.color = '#ffdd88'
  } else if (type === 'camera') {
    const camHelper = new THREE.CameraHelper(new THREE.PerspectiveCamera(50, 1, 0.1, 10))
    camHelper.position.set(3, 2, 3)
    scene.add(camHelper)
    camHelper.userData.id = id
    threeObjects.set(id, camHelper)
  } else if (type === 'empty') {
    const axes = new THREE.AxesHelper(0.5)
    axes.position.set(Math.random() * 2 - 1, 0, Math.random() * 2 - 1)
    scene.add(axes)
    axes.userData.id = id
    threeObjects.set(id, axes)
  }

  return sceneObj
}

export function removeThreeObject(id: string) {
  const scene = sceneRef
  if (!scene) return
  const obj = threeObjects.get(id)
  if (obj) { scene.remove(obj); threeObjects.delete(id) }
  const light = threeLights.get(id)
  if (light) { scene.remove(light); threeLights.delete(id) }
}

export function useSceneSetup(canvasRef: React.RefObject<HTMLCanvasElement>, containerRef: React.RefObject<HTMLDivElement>) {
  const animRef = useRef<number>(0)

  const { projection } = useEditorStore()

  useEffect(() => {
    const canvas = canvasRef.current
    const container = containerRef.current
    if (!canvas || !container) return

    const w = container.clientWidth
    const h = container.clientHeight

    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x1a1a1a)
    sceneRef = scene

    const cam = new THREE.PerspectiveCamera(50, w / h, 0.01, 1000)
    cam.position.set(5, 4, 6)
    cam.lookAt(0, 0, 0)
    cameraRef = cam
    updateCameraPosition()

    const ortho = new THREE.OrthographicCamera(-5, 5, 3.5, -3.5, 0.01, 1000)
    ortho.position.set(0, 10, 0); ortho.lookAt(0, 0, 0)
    orthoCameraRef = ortho

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.setSize(w, h)
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap
    rendererRef = renderer

    const grid = new THREE.GridHelper(20, 20, 0x333333, 0x222222)
    grid.name = '_grid'; scene.add(grid)

    const axes = new THREE.AxesHelper(3)
    axes.name = '_axes'; scene.add(axes)

    const ambient = new THREE.AmbientLight(0x404040, 0.5)
    ambient.name = '_ambient'; scene.add(ambient)

    const sun = new THREE.DirectionalLight(0xffffff, 1.2)
    sun.position.set(8, 12, 6); sun.castShadow = true; sun.name = '_sun'; scene.add(sun)

    const store = useEditorStore.getState()
    const initial = spawnObject('cube')
    if (initial) store.addObject(initial)

    const animate = () => {
      animRef.current = requestAnimationFrame(animate)
      const s = useEditorStore.getState()
      const activeCamera = s.projection === 'orthographic' ? orthoCameraRef! : cameraRef!
      renderer.render(scene, activeCamera)
    }
    animate()

    const onResize = () => {
      const nw = container.clientWidth, nh = container.clientHeight
      renderer.setSize(nw, nh)
      cam.aspect = nw / nh; cam.updateProjectionMatrix()
    }
    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(animRef.current)
      window.removeEventListener('resize', onResize)
      renderer.dispose()
      sceneRef = null; cameraRef = null; rendererRef = null; orthoCameraRef = null
      threeObjects.clear(); threeLights.clear()
    }
  }, [canvasRef, containerRef])

  const syncGrid = useCallback((show: boolean) => {
    const g = sceneRef?.getObjectByName('_grid')
    if (g) g.visible = show
  }, [])

  const syncAxes = useCallback((show: boolean) => {
    const a = sceneRef?.getObjectByName('_axes')
    if (a) a.visible = show
  }, [])

  return { updateCameraPosition, syncGrid, syncAxes }
}
