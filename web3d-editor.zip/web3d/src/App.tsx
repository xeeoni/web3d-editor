import React from 'react'
import Topbar from './components/Topbar'
import Outliner from './components/Outliner'
import Viewport from './components/Viewport'
import Properties from './components/Properties'
import Statusbar from './components/Statusbar'
import { useState } from 'react'

export default function App() {
  const [coord] = useState({ x: 0, y: 0 })

  return (
    <div
      className="grid w-screen h-screen overflow-hidden font-mono text-[11px] text-[#ccc]"
      style={{
        gridTemplateRows: '32px 1fr 26px',
        gridTemplateColumns: '220px 1fr 240px',
        background: '#1a1a1a',
      }}
    >
      {/* Topbar */}
      <div style={{ gridColumn: '1 / -1' }}>
        <Topbar />
      </div>

      {/* Left Sidebar */}
      <div className="overflow-hidden border-r border-[#111]">
        <Outliner />
      </div>

      {/* Main Viewport */}
      <div className="overflow-hidden">
        <Viewport />
      </div>

      {/* Right Sidebar */}
      <div className="overflow-hidden border-l border-[#111]">
        <Properties />
      </div>

      {/* Status Bar */}
      <div style={{ gridColumn: '1 / -1' }}>
        <Statusbar coord={coord} />
      </div>
    </div>
  )
}
