# Web3D Editor

A web-based 3D editor inspired by Blender, built with React, TypeScript, Three.js, and Tailwind CSS.

## 🚀 Quick Start

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/web3d-editor.git
cd web3d-editor

# Install dependencies
npm install

# Start dev server
npm run dev
```

Open `http://localhost:5173` in your browser.

## 🏗️ Build for Production

```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
src/
├── components/
│   ├── Topbar.tsx       # Menu bar (Add, modes, viewport options)
│   ├── Outliner.tsx     # Scene hierarchy panel
│   ├── Viewport.tsx     # Main 3D viewport (Three.js canvas)
│   ├── Properties.tsx   # Object properties panel
│   ├── Gizmo.tsx        # Axis orientation gizmo
│   ├── Timeline.tsx     # Animation timeline
│   └── Statusbar.tsx    # Bottom status bar
├── hooks/
│   ├── useScene.ts      # Three.js scene lifecycle & object spawning
│   └── useOrbitControls.ts  # Mouse orbit/pan/zoom
├── store/
│   └── editorStore.ts   # Zustand global state
├── App.tsx
├── main.tsx
└── index.css
```

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `G` | Grab / Move tool |
| `R` | Rotate tool |
| `S` | Scale tool |
| `Shift+D` | Duplicate selected |
| `Delete` | Delete selected |
| `Tab` | Toggle Object / Edit mode |
| `1` | Front view |
| `3` | Right view |
| `7` | Top view |
| `5` | Toggle Perspective / Orthographic |

## 🖱️ Viewport Navigation

| Action | Control |
|--------|---------|
| Orbit | Middle-mouse drag |
| Pan | Right-click drag |
| Zoom | Scroll wheel |
| Select | Left-click |

## ✅ Features

- **Viewport**: WebGL rendering, orbit controls, perspective/orthographic, view presets
- **Objects**: Cube, Sphere, Plane, Cylinder, Cone, Torus, Lights, Camera, Empty
- **Scene Outliner**: Object list, visibility toggle, search, rename
- **Properties Panel**: Transform (XYZ), Material (color, roughness, metallic), Light (color, intensity)
- **Animation**: Timeline, keyframes, play/pause, auto-key
- **Gizmo**: Interactive XYZ axis indicator

## 🗺️ Roadmap

- [ ] Edit Mode (vertex/edge/face manipulation)
- [ ] Node-based Material Editor
- [ ] GLTF / OBJ import & export
- [ ] Asset Browser
- [ ] Drag-and-drop objects
- [ ] Cloud save & project versioning
- [ ] Collaboration (WebSocket)
- [ ] Path tracing (WebGPU)

## 🛠️ Tech Stack

- **React 18** + **TypeScript**
- **Three.js r158**
- **Zustand** (state management)
- **Tailwind CSS** (styling)
- **Vite** (build tool)

## 📄 License

MIT
